
def compress():
    print('compress image')